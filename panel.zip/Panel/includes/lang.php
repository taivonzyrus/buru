<?php
	$lang = array();

	// admin.php
	$lang['Next'] = 'Next';
	$lang['Previous'] = 'Previous';

	// chart.php
	$lang['Count'] = 'Numbers';
	$lang['Hours'] = 'Hours';
	$lang['Days'] = 'Days';
	$lang['New password additions in the past month'] = 'New password additions in the past month';
	$lang['New password additions in the past 24 hours'] = 'New password additions in the past 24 hours';
	$lang['OS popularity'] = 'OS popularity';
	$lang['Additional OS statistics'] = 'Additional OS statistics';

